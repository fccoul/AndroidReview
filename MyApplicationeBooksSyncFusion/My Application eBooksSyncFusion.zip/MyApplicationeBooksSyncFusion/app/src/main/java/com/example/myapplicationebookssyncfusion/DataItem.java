package com.example.myapplicationebookssyncfusion;

public class DataItem {

    String Name;
    String PhoneNumber;

    public DataItem(String name,String phoneNumber)
    {
        this.Name=name;
        this.PhoneNumber=phoneNumber;
    }
}
